import './assets/index.ts-CrlbSCJU.js';
